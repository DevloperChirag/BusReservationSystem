CREATE DATABASE bus_reservation;
USE bus_reservation;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    username VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    weburl VARCHAR(225),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
CREATE TABLE `bus_reservation`.`admin` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  `username` VARCHAR(50) NOT NULL,
  `password` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `username_UNIQUE` (`username` ASC) VISIBLE);
  
  CREATE TABLE `bus_details` (
  `bus_no` varchar(45) NOT NULL,
  `Source` varchar(60) NOT NULL,
  `destination` varchar(60) NOT NULL,
  `price` varchar(10) NOT NULL,
  `seat` varchar(10) NOT NULL,
  `movement` varchar(45) NOT NULL,
  `time` varchar(45) NOT NULL,
  `date` date NOT NULL,
  UNIQUE KEY `bus_no_UNIQUE` (`bus_no`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


desc users;
drop table bus_details;
desc admin;
select * from admin;